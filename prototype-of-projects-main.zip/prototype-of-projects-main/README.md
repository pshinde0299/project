This is java full stack project of Eduladdr
