import abs.MetroBill;

public class Main {


    public static void main(String[] args) {
     

      MetroBill metroBill = new MetroBill();

      System.out.println(metroBill.oneWay());

      System.out.println(metroBill.roundTrip());

      System.out.println(metroBill.womenPassenger());

      System.out.println(metroBill.ChildPassenger());

      }


    }

  
    
